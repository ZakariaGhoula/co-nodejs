module.exports = {
    'secret': 'cookoutisforthebest1992gUc4WVsZ',
    'database': 'mongodb://127.0.0.1:27017/cookout-dev',
    'port': process.env.PORT || 3000
};